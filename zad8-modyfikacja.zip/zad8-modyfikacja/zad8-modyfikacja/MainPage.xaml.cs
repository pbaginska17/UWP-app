﻿using System;
using System.Collections.Generic;
using System.IO;
using static System.IO.StreamReader;

using System.Text;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

//Szablon elementu Pusta strona jest udokumentowany na stronie https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x415

namespace zad8_modyfikacja
{
    /// <summary>
    /// Pusta strona, która może być używana samodzielnie lub do której można nawigować wewnątrz ramki.
    /// </summary>
    public sealed partial class MainPage : Page
    {
         
        public MainPage()
        {
            this.InitializeComponent();
        }
        private async void Button_Click(object sender, RoutedEventArgs e)
        { 
            var path = @"MyText.txt";
           var folder = Windows.ApplicationModel.Package.Current.InstalledLocation;
           
            // acquire file
            var file = await folder.GetFileAsync("MyText.txt");
            var readFile = await Windows.Storage.FileIO.ReadLinesAsync(file);
            readFile.ToString();
            MediaElement mediaElement = new MediaElement();
        var synth = new Windows.Media.SpeechSynthesis.SpeechSynthesizer();
            string toRead=" ";
            foreach(var line in readFile)
            {
                toRead += line;
            }
            Windows.Media.SpeechSynthesis.SpeechSynthesisStream stream = await synth.SynthesizeTextToStreamAsync(toRead);
        mediaElement.SetSource(stream, stream.ContentType);
            /*Windows.Media.SpeechSynthesis.SpeechSynthesisStream stream = await synth.SynthesizeTextToStreamAsync("Hello World");
            mediaElement.SetSource(stream, stream.ContentType);*/
            mediaElement.Play();

        }

}
    }

